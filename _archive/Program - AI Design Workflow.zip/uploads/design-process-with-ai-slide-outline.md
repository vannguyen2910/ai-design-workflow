---
title: "Your Design Process, with AI"
lesson_file: "design-process-with-ai-lesson.md"
level: ""
slide_count: 69
duration: "2 x 90 min (buổi 1 dạy, buổi 2 thực hành)"
status: draft
built_deck: ""
last_synced: 2026-10-07
---

> **Source of truth:** `design-process-with-ai-lesson.md`
> Mọi thay đổi về nội dung (activity, phase, timing, khái niệm) được làm ở file lesson trước, rồi phản ánh sang đây.
> File này chỉ chứa những gì thuộc về slide: layout type, text trên slide, visual hint, kicker và speaker notes.
> Xem `CLAUDE.md` → Lesson file sync rule để biết thay đổi nào kéo theo cập nhật bên nào.

> **Layout vocabulary cố định.** Mỗi header `###` bên dưới dùng một trong các type trong `_system/Themes/slide-design/RULES.md`: Cover, Section divider, Statement, Numbered, Compare, Process, Quote, Milestone, Practice, End, Diagram, Formula, Image. `SECTION`, `COMPARISON` và `ACTIVITY` là drift, không phải type hợp lệ: dùng `SECTION DIVIDER`, `COMPARE`, `MILESTONE`. Tên field (Kicker, Title, On-slide, Speaker notes, Visual hint) giữ nguyên tiếng Anh; nội dung bên trong là tiếng Việt.

> **Copy standard:** mọi Kicker, Title và dòng On-slide phải đọc được trong một cái nhìn. Không câu nào trên slide dài quá khoảng 15 từ. Phần giải thích thêm hoặc ví dụ nằm trong speaker notes hoặc file lesson, không nằm trên slide. Speaker notes dùng ngôi "mình".

> **Deck status:** chưa có deck nào được build từ outline này.

---

## Session metadata

| Field | Value |
|---|---|
| Program | AI Design Workflow |
| Track / session | Module 1 (tuần 1) của series: buổi 1 dạy, buổi 2 thực hành, mỗi buổi 90 phút, online, 7 đến 8 học viên, cách nhau khoảng ba ngày |
| Stage | Foundation |
| Prior session | Không có (mở đầu series) |
| Next session | Discover the Problem |
| Running example | App meal-kit theo gói đăng ký (case card hư cấu cho phần demo); học viên áp dụng các bước vào case của chính mình |

---

## Slide structure: 69 slides

- Một deck cho cả hai buổi của module 1: **42 slide trong luồng dạy** và **27 slide Appendix** (method reference, đặt sau slide END, chỉ mở khi học viên hỏi). **Buổi 1 (dạy) = slide 1 đến 31. Buổi 2 (thực hành) = slide 32 đến 42.** Buổi 1 là buổi dạy: chỉ có câu hỏi và nói chuyện theo cặp, không có output; mọi output nằm ở buổi 2. Buổi 1 kết thúc bằng 15 phút hỏi đáp, rồi một slide nhắc chuẩn bị cho buổi 2.
- Arc: **Tương lai của nghề và hướng đi của bạn** (10, tính cả cover: divider, số liệu, áp lực nằm ở đâu, ba slide cho ba hướng đi, warm-up nói về hướng của bạn, lập trường partner, dòng một câu) → **Quy trình thiết kế của bạn, cùng AI** (6: một divider, stage map, bốn slide stage) → **Một task làm hai lần, thuật ngữ và data safety** (9, gồm Activity 1 là nói chuyện theo cặp) → **Tiếp theo là gì, hub, kết thúc buổi 1, hỏi đáp, nhắc chuẩn bị** (6) → **Buổi 2: data rules, file, folder và case folder** (8, gồm Activity 2, 3 và 4) → **Homework và kết thúc buổi 2** (3).
- Khớp với mười phase của lesson. Phase 1 = slide 1–10. Phase 2 = slide 11–16. Phase 3 = slide 17–23. Phase 4 = slide 24–25. Phase 5 = slide 26–31. Phase 6 = slide 32–33. Phase 7 = slide 34–35. Phase 8 = slide 36–38. Phase 9 = slide 39. Phase 10 = slide 40–42. Appendix = slide 43–69.
- Thời gian trên màn hình chỉ xuất hiện ở slide `MILESTONE` (`Num:` = số phút): warm-up = 3, Activity 1 = 4, Activity 2 = 8, Activity 3 = 40, Activity 4 = 10. Timing các phase: buổi 1 gồm Phase 1 20, Phase 2 10, Phase 3 19, Phase 4 12, Phase 5 21 (6 phút giảng và 15 phút hỏi đáp), tổng 82 trên 90 phút, buffer 8 phút (slide nhắc chuẩn bị cho buổi 2 chiếu trong buffer). Buổi 2 gồm Phase 6 14, Phase 7 9, Phase 8 40, Phase 9 16, Phase 10 6, tổng 85 trên 90 phút, buffer 5 phút. Phase 1 chia: ground rule 1, số liệu 4, áp lực nằm ở đâu 2, ba hướng đi 7, warm-up 3, lập trường partner và dòng một câu 3. Phase 2 chia: stage map 2, bốn stage mỗi stage 2. Phase 3 chia: demo 7, thuật ngữ trong thực tế 8, Activity 1 4. Phase 4 chia: data safety 8, bài phân loại 4. Phase 5 chia: series map 2, hub và chia sẻ 2, kết thúc phần giảng 2, hỏi đáp 15.
- Phase 2 chỉ nói mỗi stage gồm gì và AI hỗ trợ ở đâu, không đi vào từng design method. Các method, thuật ngữ và chi tiết folder nằm trong pre-read brief, nên deck không có slide nào đọc định nghĩa thành tiếng.
- Mọi con số trên slide ở Phase 1 ghi nguồn, năm và cỡ mẫu. Chỉ dùng số liệu đã đọc ở nguồn gốc (xem `programs/ai-design-workflow/04-future-of-design-careers.md`); không đưa lên slide những con số mà mục 10 của file đó xếp vào danh sách chưa dùng.
- Buổi 2 là buổi thực hành, nên deck chỉ giữ slide cho phần ngắn đầu buổi (folder, working file) và các activity; không có slide giảng mới.

---

## Slides

### COVER
- Year: 2026 · Winnie Nguyen
- Stage: Foundation
- Title: Your Design\nProcess, *with AI*
- Subtitle: Where careers are heading, the four stages you know, and the workspace to run it in
- Author: Winnie Nguyen
- Credentials:
  - Senior Product Designer
  - Master of UX & Service Design
  - Product Design Instructor
- Right panel photo: Ảnh thật bàn tay một designer trên laptop với cây folder đang mở, ánh sáng ấm, gần gũi, không mang hơi hướng công nghệ viễn tưởng
- Speaker notes:
  - Chào cả nhóm và nói lesson này để làm gì: nói về tương lai của nghề và ba hướng đi, nhắc lại nhanh bốn stage có thêm AI, một cách dùng AI an toàn, và một folder cho case của chính các bạn
  - Mọi lesson sau đều dùng những thứ này, nên mình cài đặt một lần ngay từ đầu
  - Nêu lập trường của cả series: designer cùng định nghĩa requirement với product và business
  - Nói rõ lớp ưu tiên designer; nếu có PO, PM hoặc BA thì các bạn học cùng một workflow, không cần build prototype từ đầu
  - Nói rõ format: hai buổi 90 phút mỗi tuần; buổi hôm nay dạy, buổi sau thực hành trên case của chính bạn; homework chỉ làm tiếp phần đã bắt đầu, tối đa 45 phút
- 🎨 Visual hint: Cover layout, cố định. Panel trái trắng với dòng năm, nhãn stage, title (accent ở dòng 2) và subtitle. Panel phải là ảnh thật với gradient tối, tên và ba dòng credentials ở góc dưới trái.

---

## 1. Where design is heading, and your direction

---

### SECTION DIVIDER · Where design is heading
- Num: 01
- Kicker: A question many of you asked
- Title: What happens to UI/UX\n*when AI is everywhere?*
- Speaker notes:
  - Mở bằng câu hỏi mà nhiều bạn đã hỏi mình: AI phổ biến thì UI/UX và product design sẽ ra sao?
  - Nói trước: có số liệu có nguồn, có hướng đi cụ thể, và cũng có chỗ chưa ai đo được; mình sẽ nói rõ từng chỗ
  - Nói ground rule của lớp trong một hơi: những gì chia sẻ trên lớp ở lại trong lớp; ẩn danh trước; không ai bắt buộc phải trình bày công việc confidential
  - Case card của khoá luôn sẵn sàng nếu case của bạn quá nhạy cảm
  - **Nhắc cả lớp:** cứ ghi câu hỏi vào chat bất cứ lúc nào; 15 phút cuối buổi để trả lời, câu nào chưa kịp thì mình trả lời sau bằng văn bản
- 🎨 Visual hint: TYPOGRAPHIC. Nền paper-deeper lavender nhạt, số phần lớn, title có accent ở dòng 2.

---

### NUMBERED · What the data says
- Kicker: Four findings, with sources
- Title: Nearly everyone uses AI.\n*The job is changing.*
- On-slide:
  - 01 · 91% designer dùng AI mỗi tuần, trung bình bảy tool (khảo sát 906 designer, 2026)
  - 02 · Nghề chưa co lại: BLS dự báo +7% (2024 đến 2034), mọi ngành +3,1%
  - 03 · Entry level khan hiếm, senior phục hồi nhanh hơn (NN/g, 2026)
  - 04 · Một nửa designer được khảo sát đã đưa code do AI tạo lên production
- Speaker notes:
  - Với mỗi con số, nói nguồn, năm và cỡ mẫu. 01 và 04: Designer Fund và Foundation Capital, AI in Design 2026, 906 designer, tự khai báo, không phải mẫu ngẫu nhiên; nói "trong khảo sát", không nói "cả nghề"
  - 02: BLS Mỹ. Bảng mới hơn (2025 đến 2035) gộp developer và designer, cho ra 5%, và nói AI "may soften" mức tăng; hai con số dùng cách gộp khác nhau, đừng so trực tiếp
  - 03: Nielsen Norman Group, State of UX in 2026; đây là phân tích của chuyên gia, không phải khảo sát
  - **Thêm một con số về cảm nhận** (Figma, State of the Designer 2026, trích qua nguồn thứ cấp; nếu chưa xác nhận ở báo cáo gốc thì bỏ bullet này):
    - 36% nói ngành đã tốt hơn, 35% nói tệ hơn, 29% nói không đổi
    - Cùng tool, cảm nhận ngược nhau
    - Mình đọc là khác biệt nằm ở cách làm việc; đây là cách đọc của mình, không phải kết luận của báo cáo
  - Trước khi dạy, xác nhận con số 36/35/29 trong báo cáo gốc của Figma (cần điền form miễn phí)
  - Bốn phút cho slide này
- 🎨 Visual hint: TYPOGRAPHIC. Numbered, bốn mục; số liệu lớn, nguồn là dòng xám nhỏ bên dưới mỗi mục.

---

### COMPARE · Where the pressure is
- Kicker: Our reading of the evidence
- Title: Producing screens,\n*or deciding what to build?*
- On-slide:
  - Trái, Làm ra screen từ brief: AI nén nhanh nhất; entry level chịu áp lực nhiều nhất
  - Phải, Quyết định làm gì và đo thế nào: research, framing, judgment; senior phục hồi nhanh hơn
- Speaker notes:
  - **Đây là suy luận của mình**, dựa trên hai nguồn:
    - NN/g 2026: entry level khan hiếm, senior phục hồi nhanh hơn
    - Stanford: người 22 đến 25 tuổi trong các nghề chịu tác động mạnh của AI mất khoảng 16% việc làm tương đối, người có kinh nghiệm ổn định; nghiên cứu này không tách riêng designer
  - Không có nguồn nào đo trực tiếp nhóm "designer nhận brief rồi làm screen"; đừng nói như một phát hiện, và đừng dùng để doạ
  - Nhấn mạnh phía phải: đây là phần AI chưa làm thay được, và cũng là phần series dạy
  - Hai phút cho slide này
- 🎨 Visual hint: SCHEMATIC. Compare hai cột. Cột trái trơn, cột phải purple đặc với chữ trắng.

---

### NUMBERED · Path 1, strategic designer
- Kicker: Senior generalist
- Title: Choose the problem\n*worth solving*
- On-slide:
  - 01 · Làm gì: cùng product và business chọn vấn đề đáng giải
  - 02 · Kỹ năng: research, framing, stakeholder management, judgment
  - 03 · Bằng chứng: NN/g 2026, senior và generalist phục hồi nhanh hơn
  - 04 · Trong khoá: tuần 2 đến 4, và hub làm bằng chứng cho lập luận
- Speaker notes:
  - Khoảng hai phút rưỡi cho mỗi hướng (bảy phút cho cả ba); mỗi hướng nêu làm gì, kỹ năng, bằng chứng và khoá giúp được gì
  - NN/g mô tả đây là những "adaptable generalists" coi UX là việc giải quyết vấn đề mang tính chiến lược, không phải sản xuất deliverable
  - Mức bằng chứng: vừa; một bài có thẩm quyền cộng một nghiên cứu gián tiếp
  - UX research là một hướng liên quan: NN/g nhắc research là điểm tạo khác biệt; tuần 2 sẽ làm phỏng vấn user theo cặp
- 🎨 Visual hint: TYPOGRAPHIC. Numbered, bốn mục, số purple.

---

### NUMBERED · Path 2, design builder
- Kicker: Design engineer
- Title: Build it,\n*ship it*
- On-slide:
  - 01 · Làm gì: dựng prototype chạy được, đưa lên production bằng AI coding tool
  - 02 · Kỹ năng: design system, kiểm tra file agent đã sửa, đọc output
  - 03 · Bằng chứng: một nửa designer được khảo sát đã ship code do AI tạo (2026)
  - 04 · Trong khoá: tuần 5 đến 6, prototype và refine
- Speaker notes:
  - Bằng chứng về xu hướng ở mức vừa; số liệu về tuyển dụng thì yếu, các con số tăng trưởng trên job board chưa đáng tin; không đưa lên slide
  - Khoá không biến bạn thành engineer: bạn chỉ đạo AI coding tool và kiểm tra những gì nó đã làm
  - Nếu lớp có PO, PM hoặc BA: họ dùng design system có sẵn và để AI tạo template; hướng này cho họ thấy nó trông như thế nào
- 🎨 Visual hint: TYPOGRAPHIC. Numbered, bốn mục, số purple.

---

### NUMBERED · Path 3, AI product designer
- Kicker: Designing products with AI inside
- Title: Design the behaviour,\n*not just the screen*
- On-slide:
  - 01 · Làm gì: thiết kế hành vi, ranh giới, lỗi và niềm tin của sản phẩm có AI
  - 02 · Kỹ năng: hiểu hallucination, grounding, đánh giá output, conversation design
  - 03 · Bằng chứng: được nhắc là chuyên môn đang lên; số liệu chưa đáng tin
  - 04 · Trong khoá: chỉ có nền tảng; khoá không dạy thiết kế sản phẩm AI
- Speaker notes:
  - **Nói thẳng:** khoá này dạy cách dùng AI để làm việc, không dạy cách thiết kế một sản phẩm AI. Hiểu hallucination, grounding và "unknown" là nền tảng tốt cho hướng này, phần còn lại bạn tự đi tiếp
  - Bằng chứng: NN/g và các blog nghề nghiệp nêu AI UX và conversation design là chuyên môn đang lên; con số tăng trưởng mình tìm thấy không truy ngược được nên không đưa lên slide
  - Ba hướng không loại trừ nhau, và đây là xu hướng chứ không phải sự đảm bảo
  - Hướng junior thiên về execution (wireframe, sản xuất asset) là hướng chịu áp lực nhiều nhất; đây là lý do chọn hướng sớm có ích
- 🎨 Visual hint: TYPOGRAPHIC. Numbered, bốn mục, số purple; dòng 04 dùng màu ochre để nhấn giới hạn của khoá.

---

### MILESTONE · Warm-up, your direction
- Num: 3
- Kicker: Pairs
- Title: Which way\ndo you *lean?*
- Sub: Nói với bạn cặp, 30 giây mỗi người. Viết ra file ở buổi sau.
- Speaker notes:
  - Ba phút, theo cặp: hướng bạn đang nghiêng về, và vì sao?
  - Chưa ghi gì; mọi người viết `my-direction.md` ở đầu buổi 2
  - Không ai phải chọn dứt khoát; file này được xem lại ở tuần 7 và được phép đổi
  - Đi quanh và ghi lại phân bố hướng của lớp để chọn ví dụ cho các tuần sau
  - Nếu ai bí, hỏi: "Nếu chỉ chọn một kỹ năng để xây trong bảy tuần, bạn chọn gì?"
- 🎨 Visual hint: TYPOGRAPHIC. Milestone layout nền purple, số phút lớn, không có diagram.

---

### COMPARE · Start from a finished brief, or shape it together?
- Kicker: The stance of this series
- Title: Start from a brief,\nor *shape it together?*
- On-slide:
  - Trái, Từ brief có sẵn: kiểm tra, thiết kế, bàn giao. Nhanh, nhưng giả định vấn đề đã đúng
  - Phải, Cùng định hình: bắt đầu từ câu hỏi của business, thống nhất outcome với product, thiết kế đúng thứ đã thống nhất
- Speaker notes:
  - Brief từ product thường là điểm xuất phát rất tốt. Không phải brief nào cũng có vấn đề; không ai đang sửa ai
  - Biến brief thành screen là phần AI làm nhanh nhất. Phần AI không làm thay được là cùng chọn vấn đề đáng giải quyết và thống nhất thế nào là thành công
  - Cần cả hai phía: design vào sớm với evidence, product và business chia sẻ điều họ biết về vấn đề và ràng buộc
  - Nếu lớp có PO, PM hoặc BA, mời họ nói họ cần gì từ design
  - **Thành thật về mức độ làm việc chung:** có bạn làm sát product mỗi ngày, có bạn chỉ liên lạc qua người trung gian, có bạn chưa có cơ hội trao đổi
  - Workflow vẫn chạy được trong cả ba trường hợp; lesson tiếp theo sẽ dạy cách làm
  - Đừng hứa là cuộc họp đó sẽ xảy ra với tất cả mọi người
- 🎨 Visual hint: SCHEMATIC. Compare hai cột. Cột trái trơn, cột phải purple đặc với chữ trắng, đúng theo compare layout.

---

### FORMULA · AI drafts. You verify. You decide.
- Kicker: AI-assisted, not AI-generated
- Title: Who made the decision?
- On-slide:
  - AI soạn nháp.
  - AI soạn nháp. Bạn kiểm tra.
  - AI soạn nháp. Bạn kiểm tra. **Bạn quyết định.**
- Speaker notes:
  - AI-generated nghĩa là AI quyết định; AI-assisted nghĩa là bạn quyết định
  - Mọi lesson sau đều dựa trên việc chọn AI-assisted một cách có chủ đích
  - Nhấn mạnh ngay bây giờ để các lesson sau không phải dạy lại
  - Nói rõ nó loại trừ điều gì: dán output sang bước tiếp theo mà chưa đọc, và để AI đưa ra quyết định
  - **Mọi stage tiếp theo đều lặp lại dòng này**
  - Hỏi: trong công việc của bạn, điều gì phải luôn là quyết định của bạn?
- 🎨 Visual hint: TYPOGRAPHIC. Ba dòng, mỗi dòng dài hơn và đậm hơn dòng trước, màu ink rồi ochre rồi purple, kết ở "Bạn quyết định."

---

## 2. Your design process, with AI

---

### SECTION DIVIDER · Your design process, with AI
- Num: 02
- Kicker: Four stages, your toolbox
- Title: Methods you know.\n*AI where it helps.*
- Speaker notes:
  - Phần này làm nhanh: mỗi stage chỉ nói hai điều, stage này gồm gì và AI hỗ trợ ở đâu; không đi vào từng method
  - Mỗi stage có cùng một câu hỏi mới: AI giúp được ở đâu, và đâu là phần bạn vẫn tự làm?
  - Chi tiết từng method sẽ có trong lesson dành cho stage đó
  - Học viên có bốn stage trong pre-read brief, kèm link tới method card cho từng method; các slide method nằm ở Appendix, chỉ mở khi học viên hỏi tới
  - Tiếp theo, một task nhỏ sẽ cho thấy làm việc với AI trông như thế nào trong thực tế
- 🎨 Visual hint: TYPOGRAPHIC. Nền paper-deeper, số phần lớn, accent ở dòng 2.

---

### DIAGRAM · The Double Diamond
- Kicker: The stage map
- Title: Four stages.\n*Open up, narrow down.*
- On-slide: Discover · Define · Develop · Deliver
- Speaker notes:
  - Nối với những gì học viên đã học: Empathise là Discover; Define là Define; Ideate và Prototype là Develop; Test là Deliver
  - Hai hình thoi: mở rộng rồi thu hẹp về vấn đề, sau đó mở rộng rồi thu hẹp về giải pháp
  - Output của mỗi stage là input của stage kế tiếp
  - Mỗi stage kết thúc bằng một checklist ngắn, một gate, trước khi công việc đi tiếp; chi tiết sẽ có sau
  - Hỏi: hiện giờ AI đang giúp bạn nhiều nhất ở stage nào?
  - Hai phút
- 🎨 Visual hint: SCHEMATIC. Double Diamond từ asset của series: hai hình thoi, bốn nhãn stage, output được ghi dưới mỗi stage, một vòng tròn gate nhỏ ở cuối mỗi stage.

---

### DIAGRAM · Discover: understand users and context
- Kicker: Discover
- Title: Understand people\n*before you design*
- On-slide:
  - Method: research questions · desk research · competitor analysis · stakeholder meetings · questionnaire · user interviews · observation
  - AI: soạn nháp câu hỏi và guide, rút dữ kiện từ nguồn của bạn, tóm tắt session
  - Bạn: câu hỏi, người thật, kiểm tra chéo với ghi chú gốc
- Speaker notes:
  - Nói stage này gồm gì và AI hỗ trợ ở đâu, khoảng một phút rưỡi; không đi vào từng method
  - **AI không phải là user, và không thể thay thế user**
  - Hỏi nhanh: khi thiếu thời gian, bạn thường bỏ qua phần nào của stage này?
  - Hai phút cho mỗi stage, bằng ba stage còn lại
  - Các slide method nằm ở Appendix; chỉ mở khi học viên hỏi tới một method
- 🎨 Visual hint: SCHEMATIC. Một stage card: các chip method thành một hàng ngang phía trên, bên dưới là hai cột, AI màu ink và Bạn màu purple. Cùng một dạng card được dùng cho ba slide tiếp theo.

---

### DIAGRAM · Define: interpret your findings
- Kicker: Define
- Title: From raw notes\nto a *design challenge*
- On-slide:
  - Năm bước: identify themes · sort and cluster · define insights · frame opportunities · set design challenges
  - AI: đề xuất theme và cluster, soạn nháp insight và câu How Might We
  - Bạn: theme nào quan trọng, việc xếp hạng, sự thống nhất với product và business
- Speaker notes:
  - Chỉ nhắc năm bước, không đi qua từng công cụ (empathy map, assumption map, jobs to be done, How Might We, journey map, Lean UX canvas)
  - **AI không đóng vai người phía product và business**
  - Hỏi: trong project gần nhất, một design challenge được thống nhất thay vì chỉ được giao sẽ thay đổi điều gì?
  - Hai phút
- 🎨 Visual hint: SCHEMATIC. Cùng stage card; năm bước là một chuỗi chip từ trái sang phải ở phía trên.

---

### DIAGRAM · Develop: brainstorm, select, prototype
- Kicker: Develop
- Title: Many ideas.\n*One reason to choose.*
- On-slide:
  - Brainstorm: Crazy 8s · How Might We ideation · brainwriting
  - Select: impact vs effort · concept sketching · storyboarding
  - Prototype: wireframes · interactive prototype · proof of concept
  - AI: mở rộng ý tưởng, dựng bản đầu. Bạn: chọn hướng, kiểm tra với nhu cầu người dùng và principle
- Speaker notes:
  - Một quyết định không có lý do được ghi lại sẽ không thể truy ngược về nhu cầu của user sau này
  - Hỏi: lần trước bạn khám phá được bao nhiêu hướng thật sự khác nhau, và lý do chọn một hướng được ghi ở đâu?
  - Hai phút
- 🎨 Visual hint: SCHEMATIC. Cùng stage card; ba nhóm chip (brainstorm, select, prototype) ở phía trên.

---

### DIAGRAM · Deliver: test and hand over
- Kicker: Deliver
- Title: Users decide\nif it *held*
- On-slide:
  - Method: internal feedback · concept testing · usability testing · A/B testing · handoff và measurement plan
  - AI: soạn nháp test plan và script, sắp xếp ghi chú, soạn nháp handoff
  - Bạn: chạy session, xếp findings theo mức độ quan trọng. AI không thay thế user thật
- Speaker notes:
  - Xếp findings theo mức độ quan trọng, không theo số lần được nhắc. Một vấn đề chỉ một người gặp nhưng khiến họ bỏ dở task vẫn quan trọng hơn một lỗi nhỏ có năm người cùng phàn nàn
  - Hỏi: handoff của bạn sẽ thay đổi thế nào nếu developer không được hỏi bạn một câu nào?
  - Hai phút
  - Kết lại phần này bằng một câu: **ở mọi stage, method là của bạn; AI giúp soạn nháp nhanh hơn, còn việc kiểm tra thuộc về bạn**
- 🎨 Visual hint: SCHEMATIC. Cùng stage card như ba slide trước.

---
## 3. One task twice, vocabulary and data safety

---

### SECTION DIVIDER · The vocabulary
- Num: 03
- Kicker: Demo, terms in action, then data safety
- Title: Words you will\n*meet every day*
- Sub: Một demo, mười thuật ngữ, rồi dữ liệu nào an toàn để dán vào
- Speaker notes:
  - Định nghĩa nằm trong pre-read brief; đừng đọc to
  - Gắn từng thuật ngữ với những gì họ vừa thấy trong demo
  - Cho họ biết sẽ có một bài tập ngắn theo cặp, rồi đến phần data safety
- 🎨 Visual hint: TYPOGRAPHIC. Nền paper-deeper, số phần lớn, accent ở dòng 2.

---

### COMPARE · One task, done twice
- Kicker: Live demo
- Title: Same case.\n*Two instructions.*
- On-slide:
  - Trái, mơ hồ: "Làm sao để cải thiện onboarding cho app meal-kit của tôi?"
  - Phải, có cấu trúc (đính kèm case card): "Chỉ dùng case card. Liệt kê năm điều bạn cần biết mà KHÔNG có trong đó. Không đoán. Nói 'unknown'. Chỉ trả về danh sách."
- Speaker notes:
  - Cho xem case card trước: một app meal-kit hư cấu mà nhiều khách mới tạm dừng sau hộp đầu tiên; nghi ngờ do giá; chưa có research
  - Chạy cả hai instruction trực tiếp (mình đã chạy thử một lần trước đó) và cho xem hai output cạnh nhau
  - Bản mơ hồ thường cho lời khuyên tự tin nhưng chung chung, và có thể nói về sản phẩm như sự thật
  - Bản có cấu trúc thường hỏi những thứ chỉ research hoặc business mới trả lời được
  - **Hỏi: bạn tin bản nào hơn, và vì sao? Chưa giải thích; các slide tiếp theo sẽ gọi tên những gì họ vừa thấy**
  - Bảy phút, gồm cả phần thảo luận
- 🎨 Visual hint: SCHEMATIC. Compare hai cột; mỗi cột có instruction ở trên và một đoạn output mẫu ngắn bên dưới. Cột phải purple.

---

### NUMBERED · Ten terms, five groups
- Kicker: The map
- Title: Ten terms.\n*Five groups.*
- On-slide:
  - 1. Các tool: AI chat tool, AI coding tool
  - 2. Nói chuyện với AI: context, context window, grounding
  - 3. Khi nó làm sai: hallucination
  - 4. Cách một số tool hành động: agent, connector (MCP)
  - 5. Mang theo chuẩn của bạn: reusable instructions
- Speaker notes:
  - Chỉ nhắc lại vì học viên đã đọc ở pre-read; hỏi hai câu nhanh để kiểm tra, ví dụ "cái nào là thứ bạn đưa cho AI, cái nào là giới hạn của AI?"
  - Gắn với demo: case card là context; "chỉ dùng case card" là grounding
  - AI-assisted vs AI-generated là thuật ngữ thứ mười, đã nói ở trên
  - Tám phút cho slide này và ba slide tiếp theo gộp lại
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, năm mục, số purple.

---

### DIAGRAM · Context and the context window
- Kicker: Group 2, talking to the AI
- Title: Everything it can see\nis *context*
- On-slide: Context window: giới hạn lượng nó giữ được cùng lúc
- Speaker notes:
  - Context là instruction của bạn, text đã dán, file đính kèm và các tin nhắn trước đó; không có gì khác về project của bạn
  - Window là giới hạn; vượt qua nó, hoặc khi tài liệu dài và lộn xộn, chi tiết sẽ nhoè hoặc rơi mất
  - **Chỉ đưa những phần mà một bước cần, không phải cả project**
  - Gắn với demo: case card là context
- 🎨 Visual hint: SCHEMATIC. Một khung gắn nhãn "context window" chứa các tile file nhỏ, vài tile rơi ra ngoài khung. Purple cho phần nằm trong, xám cho phần rơi ra.

---

### STATEMENT · Hallucination
- Kicker: Group 3, when it goes wrong
- Title: Confident,\nand *invented.*
- On-slide: Hãy để nó nói "unknown".
- Speaker notes:
  - Ví dụ: một đối thủ không tồn tại, một câu quote chưa ai nói, lời khuyên tự tin trong output mơ hồ của demo
  - AI có xu hướng luôn trả lời. Nếu không được phép nói "unknown", nó sẽ lấp chỗ trống bằng một câu nghe rất hợp lý
  - **Cho phép "unknown" và yêu cầu nguồn cho từng claim**
  - Thói quen này đi xuyên suốt cả series
  - Hỏi: bạn đã bao giờ thấy AI bịa ra thứ gì mà mãi sau bạn mới nhận ra chưa?
- 🎨 Visual hint: TYPOGRAPHIC. Title lớn, một dòng ngắn trên slide, không thêm gì khác.

---

### DIAGRAM · An agent takes many steps
- Kicker: Group 4, how some tools act
- Title: One request,\n*many steps*
- On-slide: Kiểm tra các file nó đã sửa, không chỉ câu trả lời.
- Speaker notes:
  - Agent đọc file, sửa chúng và chạy lệnh, rồi báo lại
  - AI coding tool thường hoạt động theo kiểu này
  - Vì vậy câu trả lời của agent chỉ là bản tóm tắt; kết quả thật nằm trong folder
  - Connector (MCP): giống một cái USB, cắm giữa file design và AI tool để AI đọc được thứ bạn đang làm; trước khi kết nối, hãy biết nó đọc và sửa được những gì
- 🎨 Visual hint: SCHEMATIC. Một prompt bên trái, mũi tên tách thành ba bước nhỏ (đọc, sửa, chạy), rồi một báo cáo bên phải kèm icon folder.

---

### MILESTONE · Activity 1
- Num: 4
- Kicker: Pairs
- Title: Explain it\nto a teammate
- Sub: Hai thuật ngữ. Ví dụ của riêng bạn. Bạn sẽ làm khác đi điều gì?
- Speaker notes:
  - Phát mười thẻ; mỗi người hai thẻ
  - Giải thích trong một câu, kèm ví dụ từ case của bạn
  - Bạn cặp hỏi một câu: "Từ điều đó, bạn sẽ làm khác đi điều gì?"
  - **Lắng nghe sự thay đổi hành vi, không phải định nghĩa**
  - Không có output; `glossary.md` là tuỳ chọn ở homework
- 🎨 Visual hint: TYPOGRAPHIC. Milestone layout nền purple, số phút lớn, không có diagram.

---

### NUMBERED · Three kinds of material
- Kicker: What you put in
- Title: Before you paste,\n*sort it*
- On-slide:
  - Safe: thông tin công khai, suy nghĩ của bạn, case của khoá
  - Ask first: nội bộ, không nhạy cảm; chỉ dùng tool đã duyệt
  - Never in a public tool: dữ liệu cá nhân, kế hoạch chưa phát hành, tài chính, tài liệu NDA
- Speaker notes:
  - Mọi thứ cho tới giờ là về những gì đi ra; đây là về những gì đi vào
  - **Đừng mặc định là nó private**: ở nhiều gói consumer, hội thoại có thể được dùng để cải thiện model trừ khi bạn tắt đi; hãy kiểm tra tool bạn dùng
  - Dữ liệu cá nhân ở Việt Nam thuộc luật 2025 có hiệu lực từ ngày 1 tháng 1 năm 2026; tên, email và bản ghi cũng tính; đây không phải tư vấn pháp lý
  - Chạy bài phân loại sáu thẻ theo cặp (bốn phút), rồi thảo luận chỗ bất đồng
  - Kết quả mong đợi: trang giá công khai và ghi chú về một app công khai là safe; phần còn lại là never in a public tool (ẩn danh trước nếu được)
- 🎨 Visual hint: TYPOGRAPHIC. Numbered, ba cột kèm một dòng ví dụ bên dưới; không tô màu nào ngoài số purple.

---

### PROCESS · Before you paste
- Kicker: Four habits
- Title: Check, sort,\n*clean, contain*
- On-slide:
  - 01 · Kiểm tra chính sách AI của công ty bạn
  - 02 · Phân loại tài liệu
  - 03 · Xoá tên và thông tin định danh trước
  - 04 · Giữ file confidential ngoài folder của tool
- Speaker notes:
  - Nếu chưa có chính sách thì hỏi; còn phân vân thì đừng dán
  - **Xoá thông tin định danh bằng find and replace trên máy của bạn**, không nhờ AI làm, vì như vậy dữ liệu đã bị gửi đi rồi
  - AI coding tool hoặc agent đọc toàn bộ project folder, nên hãy giữ file riêng tư ở chỗ khác
  - Output của AI có được dùng cho công việc với client hay không, và ai sở hữu nó, tuỳ công ty và quốc gia của bạn; hãy ghi lại trong case log chỗ nào đã dùng AI
  - Bạn sẽ viết data rules của riêng mình ở đầu buổi 2, trên tài liệu thật của case; cho đến lúc đó đừng dán tài liệu thật vào AI tool
- 🎨 Visual hint: SCHEMATIC. Process track bốn bước, bước ba được tô purple.

---
## 4. What comes next

---

### SECTION DIVIDER · What comes next
- Num: 04
- Kicker: The series and your hub
- Title: Where this\n*is going*
- Sub: Các lesson, hub và cách chia sẻ
- Speaker notes:
  - Kéo mọi người ra khỏi phần thực hành
  - Đây là những ý lớn cuối cùng của buổi 1: bản đồ series, hub và cách chia sẻ nó
  - Giữ đúng thời gian: hai phút mỗi phần, rồi đến hỏi đáp mười lăm phút
- 🎨 Visual hint: TYPOGRAPHIC. Nền paper-deeper, số phần lớn.

---

### DIAGRAM · The series in one picture
- Kicker: The stage map, with the lessons
- Title: From a business question\nto a *validated prototype*
- On-slide: Discover · Define · Develop · Deliver, mỗi stage kèm lesson dạy sâu method của nó
- Speaker notes:
  - Chiếu lại stage map, lần này kèm lesson dạy sâu từng method
  - Output của mỗi stage là input của stage kế tiếp
  - Một gate quyết định công việc có đi tiếp không; alignment check chạy ở mọi gate
  - Ở mỗi stage có điều cần thống nhất với product và business
  - Chúng ta bắt đầu từ câu hỏi của business, không phải một brief được giao
  - Phần nền bên dưới là thứ bạn dựng trong buổi 2
- 🎨 Visual hint: SCHEMATIC. Stage map từ asset của series: bốn cột stage kèm tên lesson bên dưới, hàng partner moves, dải alignment, thanh foundation, thanh experience hub. Cùng hình với slide stage map trước, thêm tên lesson.

---

### DIAGRAM · The Experience Hub
- Kicker: The final report
- Title: Every output.\n*One connected place.*
- On-slide: Bắt đầu từ bất kỳ quyết định nào. Lần ra nhu cầu, hypothesis, principle và test của nó.
- Speaker notes:
  - Hub là một website nhỏ gồm các page liên kết trong case folder của bạn; mỗi lesson thêm một page
  - Báo cáo cuối của series là hub hoàn chỉnh, không phải một tài liệu
  - Cho xem hub trống mở trong browser, với dữ liệu mẫu; buổi 2 mọi người sẽ copy hub vào case folder của mình
  - Trang Overview tự tính các khoảng trống cho bạn: quyết định không có nhu cầu user phía sau, hypothesis không có test
  - **Hub làm cho lập luận của bạn có thể được người khác kiểm chứng**
- 🎨 Visual hint: REAL. Screenshot trang Overview của template: menu bên trái, gate, bảng và cảnh báo bên phải.

---

### DIAGRAM · Private by default, public if you choose
- Kicker: Sharing your hub
- Title: Your hub is\n*yours to share*
- On-slide: Private: PDF hoặc folder nén. Public: GitHub, chỉ khi case được phép chia sẻ.
- Speaker notes:
  - **Hub mặc định là private**: nó nằm trong case folder của bạn và không ai thấy trừ khi bạn gửi
  - Để cho stakeholder xem, export các page chính ra PDF, hoặc gửi folder đã nén
  - Chỉ một case được phép chia sẻ (case của khoá, hoặc bản đã làm sạch từ công việc của bạn) mới có thể publish thành link trực tuyến trên GitHub; guide và homework tuỳ chọn có hướng dẫn
  - **Nếu bạn publish, bạn là người host và chịu trách nhiệm**; GitHub Pages miễn phí cần repository public, đó là lý do công việc thật được giữ private
- 🎨 Visual hint: SCHEMATIC. Hai cột. Trái, "Private (mặc định)": một folder có khoá, mũi tên tới một PDF và một file nén. Phải, "Public (tuỳ chọn)": một folder, mũi tên "upload" vào một repository, và mũi tên "Pages" tới khung browser.

---
### STATEMENT · Questions
- Kicker: 15 minutes
- Title: Ask me\n*anything*
- On-slide: Về nội dung hôm nay, hướng đi của bạn, hoặc khoá học. Ghi vào chat.
- Speaker notes:
  - Mở đầu bằng một câu hỏi cho cả lớp: bạn sẽ giải thích lại thuật ngữ nào theo cách khác, hoặc chạy stage nào với AI theo cách khác?
  - Rồi đến các câu hỏi đã ghi trong chat suốt buổi; chọn câu được nhiều người quan tâm nhất trước
  - Câu nào cần số liệu hoặc cần nghĩ thêm: trả lời ngắn và hẹn trả lời bằng văn bản sau buổi
  - Nếu hỏi đáp kết thúc sớm: để học viên hỏi về hướng đi nghề nghiệp của mình, và ai cần giúp cài AI tool thì ở lại làm cùng
  - Mười lăm phút; sau đó chiếu slide nhắc chuẩn bị cho buổi 2
- 🎨 Visual hint: TYPOGRAPHIC. Title lớn, một dòng bên dưới trên nền sáng.

---

### PRACTICE · Before session 2
- Kicker: Before the next session
- Title: Bring your\n*case*
- On-slide:
  - Chọn case của bạn; ẩn danh tên, số liệu, chi tiết chưa phát hành
  - Kiểm tra AI tool chạy được
  - Giữa hai buổi, chỉ dùng case card nếu muốn thử AI tool
- Speaker notes:
  - Không có bài tập mới; buổi 2, khoảng ba ngày nữa, mọi người viết data rules, viết hướng của mình và dựng case folder ngay trên lớp
  - Nếu case không thể mang lên lớp, dùng case card của khoá
  - **Chưa dán tài liệu thật của case vào AI tool trước khi viết data rules ở buổi 2**
  - Chiếu slide này sau phần hỏi đáp, trong thời gian buffer, để lời dặn không bị Q&A lấn át
- 🎨 Visual hint: TYPOGRAPHIC. Practice layout, ba card ngắn: "Case", "AI tool", "Case card".

---

## 5. Files, folders and your case folder (session 2)

---

### SECTION DIVIDER · Files, folders and your case folder
- Num: 05
- Kicker: What the AI works with, then hands-on
- Title: A folder\n*it can work with*
- Sub: Học layout, rồi dựng case folder của bạn
- Speaker notes:
  - Đây là buổi 2, buổi thực hành: mở bằng check-in ba phút (ai chưa chạy được AI tool, chưa chọn được case, còn băn khoăn về data rules?)
  - Rồi ba phút để mỗi người viết hai đến ba dòng vào `my-direction.md`: hướng nghiêng về, lý do, một kỹ năng muốn xây; file xem lại ở tuần 7
  - Sau đó là Activity 2 (data rules), rồi mới đến file và folder
  - Chi tiết file và folder nằm trong pre-read brief; dùng thời gian cho những chỗ mọi người hay hiểu sai
  - Hầu hết designer chưa bao giờ cần dùng text editor; design tool đã che nó đi
  - Mọi người làm trên laptop của mình, trong breakout room ba hoặc bốn người
- 🎨 Visual hint: TYPOGRAPHIC. Nền paper-deeper, số phần lớn, accent ở dòng 2.

---

### MILESTONE · Activity 2
- Num: 8
- Kicker: Your own case
- Title: Write your
*data rules*
- Sub: Ba dòng bằng lời của bạn: dán gì, không dán gì, dùng tool nào
- Speaker notes:
  - Tám phút, làm cá nhân trong breakout room; đây là lần đầu họ dùng ba nhóm dữ liệu của buổi 1 trên tài liệu thật
  - Mỗi người xếp ba tài liệu thật của case mình vào safe, ask first hoặc never in a public tool
  - Rồi viết ba dòng vào `data-rules.md`: mình được dán gì, mình sẽ không dán gì, mình dùng tool nào cho việc gì
  - **Chỗ nào chưa biết chính sách của công ty: ghi "cần hỏi", và hỏi trước tuần 2**
  - Ai dùng case card của khoá thì viết cho case card, và viết lại cho case thật sau
  - Đi quanh và hỏi: "Nếu file này lọt ra ngoài, ai sẽ biết?"
- 🎨 Visual hint: TYPOGRAPHIC. Milestone layout nền purple, số phút lớn, không có diagram.

---

---

### DIAGRAM · The case folder
- Kicker: One plain local folder
- Title: Every lesson points\nto *this folder*
- On-slide: 00-context · 01-discover · 02-define · 03-develop · 04-deliver · hub · case-log
- Speaker notes:
  - Folder local nằm trên máy của bạn, không phải file design trên server hay tài liệu cloud
  - AI coding tool mở cả folder làm project của nó và đọc mọi thứ bên trong; folder đồng bộ cloud có thể gặp lỗi giữa chừng khi đang ghi
  - Đi qua cây folder: context pack trước, rồi mỗi stage một folder
  - Folder đánh số giữ đúng thứ tự; một file cho mỗi activity cho mỗi bước AI một input có tên
  - Layout khác vẫn ổn cho project riêng của bạn; ở đây mình dùng layout này
  - Hai loại file, trong một hơi: Markdown (`.md`) là plain text bạn làm việc trong đó và AI tool xử lý ổn định; HTML là thứ browser vẽ ra, prototype và hub đều là HTML. Bạn giữ Markdown; AI dựng page khi stakeholder cần đọc
  - Sáu phút cho slide này; ba phút cho slide kế tiếp
- 🎨 Visual hint: SCHEMATIC. Một cây folder gọn, folder context được tô purple và folder hub màu ink.

---

### PROCESS · One working file, section by section
- Kicker: Keep it safe
- Title: One file.\n*Filled step by step.*
- On-slide:
  - 01 · Chỉ đưa AI những section nó cần
  - 02 · Nó chỉ trả về section của nó
  - 03 · Bạn dán vào và kiểm tra
  - 04 · Giữ bản nháp của AI tách khỏi bản bạn đã kiểm tra
- Speaker notes:
  - Mỗi activity trong series điền vào một file Markdown, mỗi bước một section
  - **AI chỉ trả về section của nó**, nên AI không viết lại được phần bạn đã chốt
  - Giữ bản nháp và bản của bạn tách nhau để thấy tỷ lệ lỗi của AI
  - Một thói quen: trước khi gõ lại project từ trí nhớ, hãy tìm file đã lưu và đính kèm nó
- 🎨 Visual hint: SCHEMATIC. Process track bốn bước, bước ba được tô purple.

---

### MILESTONE · Activity 3
- Num: 40
- Kicker: Breakout rooms
- Title: Build your\ncase folder
- Sub: Folder. File context. Hub trống. Một instruction.
- Speaker notes:
  - Bốn mươi phút; bốn bước ở slide kế tiếp
  - Học viên mà công ty cấm AI tool, hoặc case quá nhạy cảm, dùng case card của khoá cho bước bốn
  - **Ai gõ lại tóm tắt project từ trí nhớ: chỉ họ về file**
  - Để ý hub trống: thường do các page bị chuyển đi mà không kèm CSS và script; hub hiện một hộp thông báo chỉ ra hầu hết lỗi setup
- 🎨 Visual hint: TYPOGRAPHIC. Milestone layout nền purple, số phút lớn.

---

### PROCESS · Four steps
- Kicker: Activity 3
- Title: Build, write,\n*add, test*
- On-slide:
  - 01 · Tạo case folder và các subfolder
  - 02 · Viết product-and-users
  - 03 · Thêm hub trống và mở nó
  - 04 · Chạy một instruction với một file đã lưu
- Speaker notes:
  - 01: năm phút, layout chuẩn
  - 02: mười phút, product-and-users đã ẩn danh, cộng với data-rules từ Activity 2; accessibility-rules làm ở homework
  - 03: năm phút, copy template hub vào `hub/` và mở trang index trong browser
  - 04: hai mươi phút, đính kèm file product, hỏi còn thiếu gì, rồi đọc câu trả lời có phản biện
  - Instruction nằm ở slide kế tiếp
- 🎨 Visual hint: SCHEMATIC. Process track bốn bước, bước bốn được tô purple.

---

### STATEMENT · The instruction to run
- Kicker: Step 4
- Title: What is *missing?*
- On-slide: "Chỉ dùng file này. Liệt kê năm điều bạn cần biết mà KHÔNG có trong đó. Không đoán. Nếu chưa rõ, nói 'unknown'. Chỉ trả về danh sách."
- Speaker notes:
  - Đính kèm file product-and-users rồi dán instruction; đây là instruction của demo, áp dụng trên case của chính họ
  - Đọc câu trả lời có phản biện: câu nào hữu ích, câu nào chung chung, câu nào bạn tự tìm ra được?
  - **Câu hỏi coaching: "Bạn sẽ sửa gì trước khi dùng nó?"**
  - Lưu những câu hữu ích vào file open-questions trong `00-context`
  - Nếu ai nhận được câu trả lời bịa, đó chính là demo hallucination trên công việc của họ
- 🎨 Visual hint: TYPOGRAPHIC. Title lớn; instruction nằm trong một card nhạt, font monospace.

---
### MILESTONE · Activity 4
- Num: 10
- Kicker: Pairs
- Title: Swap and
*check*
- Sub: Bạn cặp chạy instruction "còn thiếu gì" trên file của bạn
- Speaker notes:
  - Mười phút, theo cặp; đổi file `product-and-users.md` đã ẩn danh
  - **Quy tắc dữ liệu:** chỉ đổi file đã ẩn danh và cả hai đồng ý; dùng trong một cuộc hội thoại mới, không dán sang nơi khác, xoá sau khi xong; case nhạy cảm thì dùng case card
  - Mỗi người đính kèm file của bạn cặp vào AI chat tool và chạy instruction ở bước 4
  - Rồi nói với bạn cặp: trong năm điều AI nói còn thiếu, điều nào thật sự thiếu, điều nào bạn cặp trả lời được ngay trong một câu
  - **Điều AI nói thiếu mà người viết trả lời được trong một câu: đó là chỗ file còn chưa đủ chi tiết**
  - Mỗi người ghi ba điều cần bổ sung
  - Sau đó, sáu phút xem một case folder trực tiếp: cả lớp hỏi, nếu mình là người lạ nhận folder này, mình hiểu người dùng và sản phẩm trong hai phút không?
- 🎨 Visual hint: TYPOGRAPHIC. Milestone layout nền purple, số phút lớn, không có diagram.

---


### PRACTICE · Assignments
- Kicker: Before the next lesson
- Title: Your folder,\n*your hub*
- On-slide:
  - Assignment 1 · Case folder (bắt buộc): layout, product-and-users, accessibility-rules, data-rules
  - Assignment 2 · Chia sẻ hub (tuỳ chọn): export ra PDF, hoặc publish nếu case được phép chia sẻ
- Speaker notes:
  - Assignment 1 khoảng hai mươi lăm phút: bổ sung ba điều từ Activity 4, viết accessibility-rules và hoàn thiện Activity 3; gửi cây folder và file product để nhận feedback, đã ẩn danh
  - Assignment 2 khoảng hai mươi phút và là tuỳ chọn; buổi tiếp theo không phụ thuộc vào nó
  - **Nếu bạn publish, bạn là người host và chịu trách nhiệm**
  - Tổng homework tối đa bốn mươi lăm phút, chỉ làm tiếp phần đã bắt đầu trên lớp
- 🎨 Visual hint: TYPOGRAPHIC. Practice layout, hai card: "Assignment 1 · Case folder" và "Assignment 2 · Chia sẻ hub".

---

### STATEMENT · Closing thought
- Kicker: To take with you
- Title: The tools will change.\n*The way of working won't.*
- On-slide: Đưa input rõ ràng. Yêu cầu nguồn. Kiểm tra. Tự quyết định.
- Speaker notes:
  - Hỏi hai hoặc ba học viên: trong năm điều AI nói còn thiếu về case của bạn, điều nào làm bạn bất ngờ nhất?
  - Nói câu kết rồi dừng lại
  - Chỉ tới lesson tiếp theo: bắt đầu từ câu hỏi của business
  - Nhắc họ đọc brief một trang của lesson tiếp theo trước buổi học
- 🎨 Visual hint: TYPOGRAPHIC. Title lớn, một dòng bên dưới trên nền sáng.

---

### END
- Kicker: See you next time
- Title: *Thank you*
- Sign: Winnie Nguyen
- Contact: Dòng thông tin liên hệ của giảng viên như các deck khác
- Speaker notes:
  - Nhắc họ gửi cây folder và file product để nhận feedback
  - Mời đặt câu hỏi
  - Ở lại với ai muốn được giúp về case folder
- 🎨 Visual hint: End layout, cố định. Nền paper-deeper nhạt, kicker, title lớn in nghiêng, chữ ký và hàng liên hệ.

## Appendix. Method reference slides

> **Không thuộc luồng dạy trực tiếp.** 27 slide tham khảo, mỗi method một slide (what, why, when, where AI helps). Chỉ mở khi học viên hỏi tới một method cụ thể, hoặc dùng lại ở lesson của stage tương ứng. Thứ tự: Discover (7), Define (5), Develop (9), Deliver (6).

---

### NUMBERED · Research questions
- Kicker: Discover · Method 1/7
- Title: Research\n*questions*
- On-slide:
  - What: Những câu hỏi cần trả lời trước khi bắt đầu thiết kế
  - Why: Chọn đúng method và biết khi nào đã đủ thông tin
  - When: Ngay từ đầu Discover
  - Where AI helps: Soạn nháp câu hỏi và chỉ ra câu hỏi mang tính dẫn dắt
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Chọn điều chưa biết nào quan trọng; thống nhất danh sách với product
  - **Lưu ý:** AI dễ hỏi những câu chung chung. Chỉ đưa context của bạn
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/01-discover/research-questions.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Desk research
- Kicker: Discover · Method 2/7
- Title: Desk\n*research*
- On-slide:
  - What: Đọc những gì product đã có: data analytics, support tickets, existing research, reviews
  - Why: Không uổng phí buổi phỏng vấn cho những điều team đã biết
  - When: Thực hiện sớm, trước primary research
  - Where AI helps: Tóm tắt tài liệu theo research questions của bạn, kèm nguồn cho từng ý
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Chọn nguồn; mở nguồn gốc cho mọi ý bạn dùng
  - **Lưu ý:** Số liệu bịa. Yêu cầu trích đoạn và vị trí
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/01-discover/desk-research.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Competitor analysis
- Kicker: Discover · Method 3/7
- Title: Competitor\n*analysis*
- On-slide:
  - What: So sánh cách các sản phẩm khác giải cùng một vấn đề, dựa trên nguồn kiểm chứng được
  - Why: Thấy điều gì phổ biến, điều gì còn thiếu, và chỗ nào có thể khác biệt
  - When: Bước vào mảng mới hoặc redesign một flow
  - Where AI helps: Gợi ý competitor còn thiếu, rút dữ kiện từ nguồn bạn đã thu thập
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Câu hỏi, tiêu chí, phần diễn giải
  - **Lưu ý:** Đối thủ bịa. Đính kèm nguồn và cho phép "unknown"
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/01-discover/competitor-analysis.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Stakeholder meetings
- Kicker: Discover · Method 4/7
- Title: Stakeholder\n*meetings*
- On-slide:
  - What: Structured discussions với product, business và engineering
  - Why: Làm rõ business question, constraints và assumptions
  - When: Ngay từ đầu, trước khi chọn research method
  - Where AI helps: Soạn nháp câu hỏi và viết bản tóm tắt để bạn xác nhận lại
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Cuộc trao đổi và sự thống nhất. AI không đóng vai người phía product và business
  - **Lưu ý:** Coi bản tóm tắt của AI là điều đã thống nhất
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/01-discover/stakeholder-meetings.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Questionnaire
- Kicker: Discover · Method 5/7
- Title: Questionnaire
- On-slide:
  - What: Bộ câu hỏi gửi cho nhiều người để thu về các câu trả lời phù hợp
  - Why: Đo mức độ phổ biến của một hiện tượng
  - When: Khi cần kiểm chứng một phát hiện ở quy mô lớn
  - Where AI helps: Soạn nháp câu hỏi và group các câu trả lời thành các topic
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Chọn đối tượng; tự đọc các câu trả lời mở
  - **Lưu ý:** AI đếm sai. Hãy đếm trong spreadsheet
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/01-discover/questionnaire.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · User interviews
- Kicker: Discover · Method 6/7
- Title: User\n*interviews*
- On-slide:
  - What: Trò chuyện một-một với các câu hỏi mở và đi sâu vào các vấn đề
  - Why: Hiểu lý do đằng sau hành vi
  - When: Khi cần hiểu động cơ và bối cảnh
  - Where AI helps: Soạn nháp interview guide, phiên âm và gợi ý topic từ transcript
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Tuyển người và dẫn cuộc trò chuyện. AI không phải người tham gia
  - **Lưu ý:** Bản tóm tắt làm mờ lời người tham gia. Giữ transcript bên cạnh
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/01-discover/user-interviews.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Observation
- Kicker: Discover · Method 7/7
- Title: Observation
- On-slide:
  - What: Quan sát user làm task thật trong bối cảnh của họ
  - Why: Thấy các workaround mà user hiếm khi nhắc tới
  - When: Khi bối cảnh quan trọng, hoặc lời nói và hành động khác nhau
  - Where AI helps: Soạn nháp các item cần quan sát, và giúp sắp xếp lại sticky note từ những gì bạn ghi nhận
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Có mặt tại hiện trường; xin phép; nhận ra pattern thật
  - **Lưu ý:** AI suy diễn thêm. Tách "đã thấy" khỏi "có thể là"
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/01-discover/observation.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Identify themes
- Kicker: Define · Method 1/5
- Title: Identify\n*themes*
- On-slide:
  - What: Gắn nhãn những gì lặp lại trong research
  - Why: Biến một đống ghi chú thành các theme truy được nguồn
  - When: Sau mỗi vòng research
  - Where AI helps: Đề xuất nhãn, kèm nguồn cho từng nhãn
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Tự đọc tài liệu gốc; giữ lại ý kiến thiểu số
  - **Lưu ý:** Theme không truy được về nguồn nào
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/02-define/01-identify-themes.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Sort and cluster
- Kicker: Define · Method 2/5
- Title: Sort and\n*cluster*
- On-slide:
  - What: Group các quan sát liên quan và đặt tên cho từng cluster
  - Why: Thấy chỗ nào evidence dày, chỗ nào còn mỏng
  - When: Khi có nhiều ghi chú hoặc theme
  - Where AI helps: Soạn nháp cách group đầu tiên để bạn sắp xếp lại
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Nhóm và tên cuối cùng; mức độ quan trọng, không chỉ tần suất
  - **Lưu ý:** Tên nhóm chung chung gộp những thứ khác nhau
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/02-define/02-sort-and-cluster.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Define insights
- Kicker: Define · Method 3/5
- Title: Define\n*insights*
- On-slide:
  - What: Một câu nói user làm gì, vì sao, và điều đó ngụ ý gì cho thiết kế
  - Why: Cho team lý do để hành động
  - When: Với mỗi cluster quan trọng
  - Where AI helps: Soạn nháp nhiều cách diễn đạt và hỏi lại "vậy thì sao?"
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Phần diễn giải; đánh dấu điều nào là suy ra
  - **Lưu ý:** Insight nghe mượt nhưng chỉ dựa trên một hai quote
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/02-define/03-define-insights.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Frame opportunities
- Kicker: Define · Method 4/5
- Title: Frame\n*opportunities*
- On-slide:
  - What: Biến insight thành các opportunity đáng giải quyết, rồi xếp hạng
  - Why: Không thể giải hết, xếp hạng cho thấy vì sao chọn cái này
  - When: Trước khi bắt đầu lên ý tưởng
  - Where AI helps: Soạn nháp opportunity statement và chỉ ra chỗ evidence còn yếu
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Việc xếp hạng; thống nhất với product và business
  - **Lưu ý:** Thứ hạng nghe hợp lý nhưng bỏ qua evidence của bạn
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/02-define/04-frame-opportunities.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Set design challenges
- Kicker: Define · Method 5/5
- Title: Set design\n*challenges*
- On-slide:
  - What: Một đến ba design challenge rõ ràng, đã thống nhất với product và business
  - Why: Một mục tiêu chung để kiểm tra mọi thiết kế
  - When: Khi các opportunity đã được xếp hạng
  - Where AI helps: Soạn nháp challenge statement, kiểm tra xem có quá rộng hoặc ẩn giải pháp không
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Việc chọn; sự thống nhất. AI không đóng vai người phía product và business
  - **Lưu ý:** Một brief đẹp nhưng không ai đồng ý
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/02-define/05-set-design-challenges.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Crazy 8s
- Kicker: Develop · Method 1/9
- Title: Crazy\n*8s*
- On-slide:
  - What: Tám ý tưởng phác nhanh trong tám phút
  - Why: Ép số lượng để vượt qua ý tưởng đầu tiên
  - When: Sau khi thống nhất các câu How Might We
  - Where AI helps: Sau khi bạn phác xong, đẩy các ý tưởng ra xa nhau hơn
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Tự phác trước; chọn ý tưởng giữ lại
  - **Lưu ý:** Bị neo vào ý tưởng của AI. Hãy phác trước
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/03-develop/01-brainstorm/crazy-8s.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · How Might We ideation
- Kicker: Develop · Method 2/9
- Title: How Might We\n*ideation*
- On-slide:
  - What: Năm đến mười ý tưởng cho mỗi câu How Might We
  - Why: Gắn mọi ý tưởng với một user need
  - When: Sau Define
  - Where AI helps: Soạn nháp thêm ý tưởng sau danh sách của bạn
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Câu hỏi; đánh giá ý tưởng nào hợp với user
  - **Lưu ý:** Ý tưởng chung chung mà sản phẩm nào cũng có
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/03-develop/01-brainstorm/how-might-we-ideation.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Brainwriting
- Kicker: Develop · Method 3/9
- Title: Brainwriting
- On-slide:
  - What: Mọi người viết ý tưởng song song và im lặng, rồi chuyền nhau để phát triển tiếp
  - Why: Tránh việc người nói to nhất định hướng cả nhóm
  - When: Khi làm việc với team
  - Where AI helps: Thêm một vòng ý tưởng sau khi mọi người xong, và group các ý tưởng
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Điều phối buổi làm việc; chọn ý đi tiếp
  - **Lưu ý:** Cho AI tham gia quá sớm
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/03-develop/01-brainstorm/brainwriting.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Impact vs effort
- Kicker: Develop · Method 4/9
- Title: Impact vs\n*effort*
- On-slide:
  - What: Đặt ý tưởng lên ma trận theo giá trị cho user và chi phí thực hiện
  - Why: Biến danh sách dài thành shortlist
  - When: Khi có nhiều ý tưởng hơn khả năng theo đuổi
  - Where AI helps: Soạn nháp cách đặt đầu tiên, kèm lý do
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Impact từ evidence của bạn; effort từ engineering
  - **Lưu ý:** AI đoán effort. Hãy hỏi người xây
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/03-develop/02-select/impact-vs-effort.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Concept sketching
- Kicker: Develop · Method 5/9
- Title: Concept\n*sketching*
- On-slide:
  - What: Phát triển hai hoặc ba hướng hàng đầu thành bản phác chi tiết hơn
  - Why: So sánh các hướng một cách công bằng
  - When: Trước khi bắt đầu build
  - Where AI helps: Biến ghi chú thô thành brief rõ ràng cho từng concept
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Bản phác và việc chọn; ghi lại lý do
  - **Lưu ý:** Ba concept thực chất giải theo cùng một cách
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/03-develop/02-select/concept-sketching.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Storyboarding
- Kicker: Develop · Method 6/9
- Title: Storyboarding
- On-slide:
  - What: Các khung hình cho thấy concept diễn ra trong bối cảnh thật của user
  - Why: Thử ý tưởng với tình huống thật, không chỉ với một screen
  - When: Khi bối cảnh hoặc nhiều bước quan trọng
  - Where AI helps: Soạn nháp khung câu chuyện và gợi ý các điểm có thể thất bại
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** User và bối cảnh; giữ cho câu chuyện thực tế
  - **Lưu ý:** Câu chuyện chỉ có trường hợp tốt nhất
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/03-develop/02-select/storyboarding.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Wireframes
- Kicker: Develop · Method 7/9
- Title: Wireframes
- On-slide:
  - What: Layout low-fidelity cho cấu trúc và hierarchy
  - Why: Đánh giá cấu trúc và flow mà không bị visual làm phân tâm
  - When: Sau khi chọn hướng
  - Where AI helps: Soạn nháp danh sách screen và các phương án layout
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Cấu trúc; kiểm tra với nhu cầu user và principle
  - **Lưu ý:** Pattern phổ biến, bỏ qua design system của bạn
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/03-develop/03-prototype/wireframes.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Interactive prototype
- Kicker: Develop · Method 8/9
- Title: Interactive\n*prototype*
- On-slide:
  - What: Bản click được, đủ state để test một task
  - Why: Test hành vi thật thay vì ý kiến
  - When: Khi cần test một flow với user
  - Where AI helps: AI coding tool dựng bản đầu từ design system của bạn
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Mọi state; việc dùng design system; accessibility
  - **Lưu ý:** Component bịa. Kiểm tra các file AI đã sửa
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/03-develop/03-prototype/interactive-prototype.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Proof of concept
- Kicker: Develop · Method 9/9
- Title: Proof of\n*concept*
- On-slide:
  - What: Bản dựng thô để trả lời đúng một câu hỏi
  - Why: Giải một câu hỏi rủi ro với chi phí thấp
  - When: Khi tính khả thi hoặc tính hữu ích là rủi ro chính
  - Where AI helps: AI coding tool dựng bản thô rất nhanh
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Câu hỏi và tiêu chí pass
  - **Lưu ý:** Bản demo bị nhầm với sản phẩm thật
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/03-develop/03-prototype/proof-of-concept.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Internal feedback
- Kicker: Deliver · Method 1/6
- Title: Internal\n*feedback*
- On-slide:
  - What: Buổi phê bình có cấu trúc: I noticed, I wonder, what if
  - Why: Bắt lỗi trước khi user thấy thiết kế
  - When: Trước khi test với user
  - Where AI helps: Group feedback và kiểm tra trước theo principle của bạn
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Chọn feedback nào để hành động
  - **Lưu ý:** Coi ý kiến đồng nghiệp là evidence từ user
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/04-deliver/01-test/internal-feedback-session.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Concept testing
- Kicker: Deliver · Method 2/6
- Title: Concept\n*testing*
- On-slide:
  - What: Cho một vài user xem concept để kiểm tra họ có hiểu không
  - Why: Nếu user không hiểu ý tưởng thì chỉnh chi tiết cũng vô ích
  - When: Trước khi dựng prototype đầy đủ
  - Where AI helps: Soạn nháp script và câu hỏi trung lập
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Tuyển người; dẫn session. AI không phải người tham gia
  - **Lưu ý:** Phản ứng giả lập trông như findings
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/04-deliver/01-test/concept-testing.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Usability testing
- Kicker: Deliver · Method 3/6
- Title: Usability\n*testing*
- On-slide:
  - What: User thật làm task thật, có hoặc không có facilitator
  - Why: Thấy thiết kế hỏng ở đâu và vì sao
  - When: Sau khi bạn tự kiểm tra, để test các hypothesis
  - Where AI helps: Soạn nháp test plan và task, dọn ghi chú
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** User thật; xếp findings theo mức độ quan trọng
  - **Lưu ý:** Bản tóm tắt làm mờ chi tiết. Truy mỗi finding về một ghi chú
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/04-deliver/01-test/usability-testing-moderated.md và usability-testing-unmoderated.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · A/B testing
- Kicker: Deliver · Method 4/6
- Title: A/B\n*testing*
- On-slide:
  - What: So sánh hai phiên bản chạy thật trên live traffic
  - Why: Biết phiên bản nào hiệu quả hơn, nhưng không biết vì sao
  - When: Khi có live traffic và hai phiên bản đáng bảo vệ
  - Where AI helps: Kiểm tra thiết kế test; phần thống kê làm trong tool chuyên dụng
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Quyết định chạy test; đọc ý nghĩa của kết quả
  - **Lưu ý:** AI không đáng tin với con số
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/04-deliver/01-test/ab-testing.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Handoff pack
- Kicker: Deliver · Method 5/6
- Title: Handoff\n*pack*
- On-slide:
  - What: Mọi thứ developer cần để build mà không phải hỏi lại
  - Why: Tránh đoán mò và làm lại
  - When: Khi thiết kế đã test xong và sẵn sàng build
  - Where AI helps: Soạn nháp spec và chỉ ra state còn thiếu
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Đối chiếu từng dòng với thiết kế thật
  - **Lưu ý:** Spec mô tả điều AI giả định
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/04-deliver/02-handoff/handoff-pack.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---

### NUMBERED · Measurement plan
- Kicker: Deliver · Method 6/6
- Title: Measurement\n*plan*
- On-slide:
  - What: Goal, signal, metric, cùng việc theo dõi gì và khi nào
  - Why: Biến "nó hiệu quả" thành điều kiểm chứng được
  - When: Lúc bàn giao, trước khi launch
  - Where AI helps: Soạn nháp các lựa chọn metric và hỏi cần theo dõi gì
- Speaker notes:
  - Slide tham khảo: chiếu khi dạy method này hoặc khi học viên hỏi
  - **Phần bạn tự làm:** Chọn metric; baseline lấy từ phía product
  - **Lưu ý:** Baseline bịa. Đánh dấu số chưa xác nhận là "assumed"
  - Card đầy đủ: `programs/ai-design-workflow/assets/method-cards/04-deliver/02-handoff/measurement-plan.md`
- 🎨 Visual hint: TYPOGRAPHIC. Numbered grid, bốn mục, số purple; mục "Where AI helps" nằm trên một card tint nhạt để tách biệt. Bốn dòng ngắn, không thêm gì khác.

---


