# Project rules

- Luôn hỏi lại người dùng (dùng ask_user) cho đến khi hiểu rõ expectation của họ, rồi mới bắt đầu làm. Không đoán khi còn mơ hồ; sau mỗi câu trả lời, nếu vẫn còn điểm chưa rõ thì hỏi tiếp.
