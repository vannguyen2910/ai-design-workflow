(function () {
  var css = document.createElement('style');
  css.textContent = '[data-step]{transition:opacity .35s ease,transform .35s ease}.step-hidden{opacity:0!important;transform:translateY(16px)}[data-reveal-instant] [data-step]{transition:none!important}@media print{.step-hidden{opacity:1!important;transform:none!important}}';
  document.head.appendChild(css);
  var manual = false, wasArmed = false;
  function ds() { return document.querySelector('deck-stage'); }
  function cur() { return document.querySelector('deck-stage > section[data-deck-active]'); }
  function all(s) { return [].slice.call((s || document).querySelectorAll('[data-step]')); }
  function nums(s) {
    var n = {};
    all(s).forEach(function (e) { n[e.getAttribute('data-step')] = 1; });
    return Object.keys(n).map(Number).sort(function (a, b) { return a - b; });
  }
  function group(s, n) { return all(s).filter(function (e) { return +e.getAttribute('data-step') === n; }); }
  function hidden(e) { return e.classList.contains('step-hidden'); }
  function armed() { var d = ds(); return manual || !!(d && d._presenting); }
  function instant(fn) {
    var r = document.documentElement; r.setAttribute('data-reveal-instant', '');
    fn();
    requestAnimationFrame(function () { requestAnimationFrame(function () { r.removeAttribute('data-reveal-instant'); }); });
  }
  function sync() {
    var a = armed();
    if (a === wasArmed) return;
    wasArmed = a;
    instant(function () { all().forEach(function (e) { e.classList.toggle('step-hidden', a); }); });
  }
  setInterval(sync, 250);
  window.addEventListener('beforeprint', function () { all().forEach(function (e) { e.classList.remove('step-hidden'); }); });
  window.addEventListener('keydown', function (e) {
    var k = e.key;
    if ((k === 'h' || k === 'H') && !e.metaKey && !e.ctrlKey && !e.altKey && !/INPUT|TEXTAREA/.test((e.target || {}).tagName || '')) {
      manual = !manual; sync(); return;
    }
    if (!armed()) return;
    var fwd = k === 'ArrowRight' || k === 'PageDown' || k === ' ';
    var back = k === 'ArrowLeft' || k === 'PageUp';
    if (!fwd && !back) return;
    var s = cur(), ns = nums(s);
    if (fwd) {
      for (var i = 0; i < ns.length; i++) {
        var g = group(s, ns[i]);
        if (g.some(hidden)) { g.forEach(function (x) { x.classList.remove('step-hidden'); }); e.stopImmediatePropagation(); e.preventDefault(); return; }
      }
    } else {
      for (var j = ns.length - 1; j >= 0; j--) {
        var h = group(s, ns[j]);
        if (h.some(function (x) { return !hidden(x); })) { h.forEach(function (x) { x.classList.add('step-hidden'); }); e.stopImmediatePropagation(); e.preventDefault(); return; }
      }
    }
  }, true);
  document.addEventListener('slidechange', function (ev) {
    if (!armed()) return;
    var d = ev.detail || {};
    var back = d.previousIndex > d.index;
    instant(function () { all(d.slide || cur()).forEach(function (x) { x.classList.toggle('step-hidden', !back); }); });
  }, true);
})();
